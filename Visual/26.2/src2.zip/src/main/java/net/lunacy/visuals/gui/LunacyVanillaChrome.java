package net.lunacy.visuals.gui;

import net.lunacy.visuals.render.UiRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.CreditsAndAttributionScreen;
import net.minecraft.client.gui.screens.DirectJoinServerScreen;
import net.minecraft.client.gui.screens.ManageServerScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.multiplayer.CodeOfConductScreen;
import net.minecraft.client.gui.screens.multiplayer.SafetyScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.options.OptionsSubScreen;
import net.minecraft.client.gui.screens.packs.PackSelectionScreen;
import net.minecraft.client.gui.screens.social.SocialInteractionsScreen;
import net.minecraft.client.gui.screens.telemetry.TelemetryInfoScreen;
import java.util.Locale;

/** Shared opt-in skin for Minecraft screens; container/inventory screens deliberately stay vanilla. */
public final class LunacyVanillaChrome {
    private LunacyVanillaChrome() {}

    public static boolean shouldTheme(Screen screen) {
        return screen != null && !(screen instanceof AbstractContainerScreen<?>) && !(screen instanceof ChatScreen)
                && !isSettingsBranch(screen) && !isOfficialMultiplayerDialog(screen);
    }

    public static boolean isSettingsBranch(Screen screen) {
        return screen instanceof OptionsScreen
                || screen instanceof OptionsSubScreen
                || screen instanceof PackSelectionScreen
                || screen instanceof TelemetryInfoScreen
                || screen instanceof CreditsAndAttributionScreen;
    }

    /** Native forms keep Minecraft's own font metrics, field padding and button labels. */
    private static boolean isOfficialMultiplayerDialog(Screen screen) {
        return screen instanceof ManageServerScreen
                || screen instanceof DirectJoinServerScreen
                || screen instanceof SafetyScreen
                || screen instanceof CodeOfConductScreen
                || screen instanceof SocialInteractionsScreen;
    }

    public static void renderBackground(Screen screen, GuiGraphicsExtractor context,
                                        int mouseX, int mouseY) {
        Minecraft client = Minecraft.getInstance();
        if (client.level == null) {
            LunacyMenuChrome.background(context, screen.width, screen.height, mouseX, mouseY, false);
        } else {
            LunacyMenuChrome.worldBackdrop(context, screen.width, screen.height);
        }
        if (isSettingsBranch(screen)) renderSettingsFrame(screen, context);
        LunacyMenuChrome.microBrand(context);
    }

    private static void renderSettingsFrame(Screen screen, GuiGraphicsExtractor context) {
        int margin = Math.clamp(Math.min(screen.width, screen.height) / 30, 10, 20);
        int top = 38;
        int bottom = screen.height - 34;
        int width = screen.width - margin * 2;
        int height = Math.max(42, bottom - top);

        UiRenderer.roundedRect(context, margin, top, width, height, 18, 0xC90B1210);
        UiRenderer.roundedBorder(context, margin, top, width, height, 18, 1,
                net.lunacy.visuals.render.ColorUtil.withAlpha(LunacyMenuChrome.GREEN, 74));
        UiRenderer.roundedRect(context, margin + 20, top + 1, Math.max(0, width - 40), 1,
                0.5, 0x2AFFFFFF);

        int railX = margin + 15;
        int railBottom = bottom - 14;
        UiRenderer.roundedRect(context, railX, railBottom - 4, 5, 5, 2.5, LunacyMenuChrome.VIOLET);
        UiRenderer.roundedRect(context, railX + 11, railBottom - 2, 58, 1, 0.5,
                net.lunacy.visuals.render.ColorUtil.withAlpha(LunacyMenuChrome.GREEN, 72));
        UiRenderer.font(context, net.lunacy.visuals.render.font.FontFace.GOLOS,
                sectionLabel(screen), railX + 78, railBottom - 7, 7.2,
                LunacyMenuChrome.MUTED);
    }

    private static String sectionLabel(Screen screen) {
        String language = Minecraft.getInstance().options.languageCode;
        Locale locale = Locale.forLanguageTag(language.replace('_', '-'));
        return screen.getTitle().getString().toUpperCase(locale);
    }
}
