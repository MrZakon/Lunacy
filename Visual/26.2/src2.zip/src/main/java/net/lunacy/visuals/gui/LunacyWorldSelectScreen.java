package net.lunacy.visuals.gui;

import net.lunacy.visuals.mixin.SelectWorldScreenAccessor;
import net.lunacy.visuals.render.ColorUtil;
import net.lunacy.visuals.render.UiRenderer;
import net.lunacy.visuals.render.font.FontFace;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;

/** Ванильный безопасный список миров внутри фирменной стеклянной сцены. */
public final class LunacyWorldSelectScreen extends SelectWorldScreen {
    public LunacyWorldSelectScreen(Screen parent) { super(parent); }

    @Override
    protected void repositionElements() {
        super.repositionElements();
        var list = ((SelectWorldScreenAccessor) (Object) this).lunacy$getLevelList();
        if (list == null) return;
        int panelWidth = Math.min(680, Math.max(320, width - 104));
        int panelHeight = Math.min(318, Math.max(170, height - 184));
        int panelX = (width - panelWidth) / 2;
        int panelY = Math.max(58, (height - panelHeight) / 2 - 4);
        list.setRectangle(panelWidth, panelHeight, panelX, panelY);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        LunacyMenuChrome.background(context, context.guiWidth(), context.guiHeight(),
                mouseX, mouseY, false);
        LunacyMenuChrome.microBrand(context);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        int panelWidth = Math.min(680, Math.max(320, width - 104));
        int panelHeight = Math.min(318, Math.max(170, height - 184));
        int panelX = (width - panelWidth) / 2;
        int panelY = Math.max(58, (height - panelHeight) / 2 - 4);
        UiRenderer.shadow(context, panelX - 8, panelY - 30, panelWidth + 16, panelHeight + 82,
                22, ColorUtil.withAlpha(0xFF000000, 150));
        UiRenderer.roundedRect(context, panelX - 8, panelY - 30,
                panelWidth + 16, panelHeight + 82, 22, 0xEE0C1411);
        UiRenderer.roundedBorder(context, panelX - 8, panelY - 30,
                panelWidth + 16, panelHeight + 82, 22, 1,
                ColorUtil.withAlpha(LunacyMenuChrome.GREEN, 65));
        UiRenderer.spacedFont(context, FontFace.UNBOUNDED_LIGHT,
                "LUNACY / " + getTitle().getString().toUpperCase(java.util.Locale.ROOT),
                panelX + 10, panelY - 19, 6.5, 0.9, LunacyMenuChrome.GREEN);
        super.extractRenderState(context, mouseX, mouseY, delta);
    }
}
