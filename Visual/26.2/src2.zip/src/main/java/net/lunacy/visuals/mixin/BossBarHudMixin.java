package net.lunacy.visuals.mixin;

import net.lunacy.visuals.ClientRuntime;
import net.lunacy.visuals.gui.LunacyMenuChrome;
import net.lunacy.visuals.module.impl.visual.ScoreboardBossBarModule;
import net.lunacy.visuals.render.ColorUtil;
import net.lunacy.visuals.render.UiRenderer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.BossHealthOverlay;
import net.minecraft.client.gui.components.LerpingBossEvent;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.UUID;

@Mixin(BossHealthOverlay.class)
public abstract class BossBarHudMixin {
    @Shadow @Final private Map<UUID, LerpingBossEvent> events;

    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true)
    private void lunacy$renderCustomBossBars(GuiGraphicsExtractor context, CallbackInfo callback) {
        ScoreboardBossBarModule module = module();
        if (module == null || !module.isEnabled()
                || module.bossBarStyle() == ScoreboardBossBarModule.PanelStyle.VANILLA) return;
        callback.cancel();
        if (module.bossBarStyle() == ScoreboardBossBarModule.PanelStyle.HIDDEN || events.isEmpty()) return;

        int width = Math.min(218, Math.max(172, context.guiWidth() / 3));
        double x = (context.guiWidth() - width) / 2.0;
        double y = 8;
        long now = System.currentTimeMillis();
        for (LerpingBossEvent bar : events.values()) {
            if (y + 25 > context.guiHeight() / 3.0) break;
            String name = fit(bar.getName().getString(), width - 16);
            double textWidth = UiRenderer.textWidth(name);
            int accent = module.accent(bar.getProgress(), now);
            UiRenderer.shadow(context, x, y, width, 24, 8, ColorUtil.withAlpha(accent, 80));
            UiRenderer.verticalGradientRoundedRect(context, x, y, width, 24, 8,
                    module.panelColor(225), module.panelColor(242));
            UiRenderer.roundedBorder(context, x, y, width, 24, 8, 1,
                    ColorUtil.withAlpha(accent, 92));
            UiRenderer.text(context, name, x + (width - textWidth) / 2.0, y + 4,
                    LunacyMenuChrome.TEXT, false);
            UiRenderer.roundedRect(context, x + 8, y + 16, width - 16, 4, 2,
                    ColorUtil.withAlpha(0xFF000000, 105));
            double progress = Math.max(0, (width - 16) * Math.clamp(bar.getProgress(), 0, 1));
            if (progress > 0.5) {
                UiRenderer.roundedRect(context, x + 8, y + 16, progress, 4, 2, accent);
            }
            y += 29;
        }
    }

    private static ScoreboardBossBarModule module() {
        ClientRuntime runtime = ClientRuntime.getNullable();
        return runtime == null ? null : runtime.module(ScoreboardBossBarModule.class);
    }

    private static String fit(String value, int maximumWidth) {
        if (UiRenderer.textWidth(value) <= maximumWidth) return value;
        String suffix = "…";
        int end = value.length();
        while (end > 0 && UiRenderer.textWidth(value.substring(0, end) + suffix) > maximumWidth) end--;
        return end == 0 ? suffix : value.substring(0, end).stripTrailing() + suffix;
    }
}
