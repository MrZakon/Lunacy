package net.lunacy.visuals.mixin;

import net.lunacy.visuals.ClientRuntime;
import net.lunacy.visuals.module.impl.visual.CameraFxModule;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public abstract class GameRendererMixin {
    @Inject(method = "calculateFov", at = @At("RETURN"), cancellable = true)
    private void lunacyvisuals$motionFov(float tickDelta, CallbackInfoReturnable<Float> callback) {
        ClientRuntime runtime = ClientRuntime.getNullable();
        CameraFxModule module = runtime == null ? null : runtime.module(CameraFxModule.class);
        Minecraft client = Minecraft.getInstance();
        if (module == null || !module.isEnabled() || client.player == null) return;
        double speed = Math.clamp(client.player.getDeltaMovement().horizontalDistance() * 4.0, 0.0, 1.0);
        callback.setReturnValue(callback.getReturnValueF() + module.fovBoost() * (float) speed);
    }
}
