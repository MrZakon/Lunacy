package net.lunacy.visuals.mixin;

import net.lunacy.visuals.ClientRuntime;
import net.lunacy.visuals.module.impl.hud.CustomCrosshairModule;
import net.lunacy.visuals.module.impl.visual.CustomChatModule;
import net.lunacy.visuals.module.impl.visual.ScoreboardBossBarModule;
import net.lunacy.visuals.gui.LunacyTheme;
import net.lunacy.visuals.render.ColorUtil;
import net.lunacy.visuals.render.UiRenderer;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.numbers.StyledFormat;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Comparator;
import java.util.List;

/** Минимальные совместимые хуки вокруг отдельных ванильных HUD-элементов. */
@Mixin(Hud.class)
public abstract class InGameHudMixin {
    @Inject(method = "extractCrosshair", at = @At("HEAD"), cancellable = true)
    private void lunacyvisuals$crosshair(GuiGraphicsExtractor context, DeltaTracker counter, CallbackInfo callback) {
        CustomCrosshairModule module = module(CustomCrosshairModule.class);
        if (module != null && module.isEnabled() && module.hidesVanilla()) callback.cancel();
    }

    @Inject(method = "displayScoreboardSidebar(Lnet/minecraft/client/gui/GuiGraphicsExtractor;Lnet/minecraft/world/scores/Objective;)V",
            at = @At("HEAD"), cancellable = true)
    private void lunacyvisuals$customScoreboard(GuiGraphicsExtractor context, Objective objective,
                                                CallbackInfo callback) {
        ScoreboardBossBarModule module = module(ScoreboardBossBarModule.class);
        if (module == null || !module.isEnabled()
                || module.scoreboardStyle() == ScoreboardBossBarModule.PanelStyle.VANILLA) return;
        callback.cancel();
        if (module.scoreboardStyle() == ScoreboardBossBarModule.PanelStyle.HIDDEN) return;

        var scoreboard = objective.getScoreboard();
        var numberFormat = objective.numberFormatOrDefault(StyledFormat.SIDEBAR_DEFAULT);
        List<SidebarRow> rows = scoreboard.listPlayerScores(objective).stream()
                .filter(entry -> !entry.isHidden())
                .sorted(Comparator.comparingInt(PlayerScoreEntry::value).reversed()
                        .thenComparing(PlayerScoreEntry::owner, String.CASE_INSENSITIVE_ORDER))
                .limit(15)
                .map(entry -> new SidebarRow(
                        PlayerTeam.formatNameForTeam(scoreboard.getPlayersTeam(entry.owner()), entry.ownerName()).getString(),
                        entry.formatValue(numberFormat).getString()))
                .toList();

        String title = objective.getDisplayName().getString();
        int contentWidth = UiRenderer.textWidth(title);
        for (SidebarRow row : rows) {
            contentWidth = Math.max(contentWidth,
                    UiRenderer.textWidth(row.name()) + 14 + UiRenderer.textWidth(row.score()));
        }
        int width = Math.clamp(contentWidth + 20, 92, 218);
        int height = 26 + rows.size() * 12 + 5;
        double x = context.guiWidth() - width - 8;
        double y = Math.max(34, context.guiHeight() * 0.5 - height / 3.0);
        long now = System.currentTimeMillis();
        int accent = module.accent(0.1, now);

        UiRenderer.shadow(context, x, y, width, height, 9, ColorUtil.withAlpha(accent, 70));
        UiRenderer.verticalGradientRoundedRect(context, x, y, width, height, 9,
                module.panelColor(226), module.panelColor(244));
        UiRenderer.roundedBorder(context, x, y, width, height, 9, 1,
                ColorUtil.withAlpha(accent, 82));
        UiRenderer.gradientRoundedRect(context, x + 8, y + 6, width - 16, 2, 1,
                module.accent(0, now), module.accent(1, now));
        String fittedTitle = fit(title, width - 20);
        UiRenderer.text(context, fittedTitle, x + (width - UiRenderer.textWidth(fittedTitle)) / 2.0,
                y + 11, LunacyTheme.dark() ? 0xFFF1F4FF : 0xFF17201C, false);
        for (int index = 0; index < rows.size(); index++) {
            SidebarRow row = rows.get(index);
            double rowY = y + 27 + index * 12;
            if (index > 0) UiRenderer.rect(context, x + 9, rowY - 3, width - 18, 1,
                    LunacyTheme.dark() ? 0x0FFFFFFF : 0x12000000);
            double scoreWidth = UiRenderer.textWidth(row.score());
            String fittedName = fit(row.name(), (int) Math.max(18, width - scoreWidth - 30));
            UiRenderer.text(context, fittedName, x + 10, rowY,
                    LunacyTheme.dark() ? 0xFFDCE5DF : 0xFF24312B, false);
            UiRenderer.text(context, row.score(), x + width - 10 - scoreWidth, rowY,
                    module.accent(index / (double) Math.max(1, rows.size() - 1), now), false);
        }
    }

    @Inject(method = "extractChat", at = @At("HEAD"))
    private void lunacyvisuals$chatGlass(GuiGraphicsExtractor context, DeltaTracker counter, CallbackInfo callback) {
        CustomChatModule module = module(CustomChatModule.class);
        if (module == null || !module.isEnabled()) return;
        int height = Math.min(176, context.guiHeight() / 2);
        int radius = module.smoothEdges() ? 7 : 1;
        int rgb = LunacyTheme.dark() ? 0x121020 : 0xF8F7F4;
        double y = context.guiHeight() - height - 40;
        UiRenderer.roundedRect(context, 3, y, 326, height, radius,
                ((int) (module.backgroundAlpha() * 255) << 24) | rgb);
        UiRenderer.roundedBorder(context, 3, y, 326, height, radius, 1, LunacyTheme.softLine());
        if (module.gradientNames()) {
            double phase = (System.currentTimeMillis() % 2400L) / 2400.0;
            UiRenderer.roundedRect(context, 5, y + 3 + phase * Math.max(1, height - 12), 2, 8, 1,
                    LunacyTheme.accent());
        }
    }

    private static <T extends net.lunacy.visuals.module.Module> T module(Class<T> type) {
        ClientRuntime runtime = ClientRuntime.getNullable();
        return runtime == null ? null : runtime.module(type);
    }

    private static String fit(String value, int maximumWidth) {
        if (UiRenderer.textWidth(value) <= maximumWidth) return value;
        String suffix = "…";
        int end = value.length();
        while (end > 0 && UiRenderer.textWidth(value.substring(0, end) + suffix) > maximumWidth) end--;
        return end == 0 ? suffix : value.substring(0, end).stripTrailing() + suffix;
    }

    private record SidebarRow(String name, String score) {}
}
