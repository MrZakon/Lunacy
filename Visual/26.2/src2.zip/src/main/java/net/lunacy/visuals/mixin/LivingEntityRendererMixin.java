package net.lunacy.visuals.mixin;

import net.lunacy.visuals.ClientRuntime;
import net.lunacy.visuals.module.impl.visual.HitColorModule;
import net.lunacy.visuals.module.impl.visual.NametagsModule;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "shouldShowName(Lnet/minecraft/world/entity/LivingEntity;D)Z", at = @At("HEAD"), cancellable = true)
    private void lunacyvisuals$hideVanillaPlayerLabel(LivingEntity entity, double squaredDistance,
                                                      CallbackInfoReturnable<Boolean> callback) {
        ClientRuntime runtime = ClientRuntime.getNullable();
        NametagsModule module = runtime == null ? null : runtime.module(NametagsModule.class);
        if (module != null && module.isEnabled() && entity instanceof AbstractClientPlayer
                && entity != net.minecraft.client.Minecraft.getInstance().player) {
            callback.setReturnValue(false);
        }
    }

    @Inject(method = "getModelTint", at = @At("HEAD"), cancellable = true)
    private void lunacyvisuals$damageColor(LivingEntityRenderState state, CallbackInfoReturnable<Integer> callback) {
        ClientRuntime runtime = ClientRuntime.getNullable();
        HitColorModule module = runtime == null ? null : runtime.module(HitColorModule.class);
        if (module != null && module.isEnabled() && state.hasRedOverlay) {
            callback.setReturnValue(module.mixColor());
        }
    }
}
