package net.lunacy.visuals.mixin;

import net.lunacy.visuals.gui.LunacyMenuChrome;
import net.lunacy.visuals.gui.LunacyVanillaChrome;
import net.lunacy.visuals.render.ColorUtil;
import net.lunacy.visuals.render.UiRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Gives each pair of real Minecraft options a readable, rounded Lunacy row. */
@Mixin(targets = "net.minecraft.client.gui.components.OptionsList$Entry")
public abstract class OptionListWidgetEntryMixin {
    @Inject(method = "extractContent", at = @At("HEAD"))
    private void lunacy$optionSurface(GuiGraphicsExtractor context, int mouseX, int mouseY,
                                      boolean hovered, float delta, CallbackInfo ci) {
        if (!LunacyVanillaChrome.isSettingsBranch(Minecraft.getInstance().gui.screen())) return;
        EntryListWidgetEntryAccessor entry = (EntryListWidgetEntryAccessor) this;
        int entryX = entry.lunacy$getX();
        int entryY = entry.lunacy$getY();
        int entryWidth = entry.lunacy$getWidth();
        int entryHeight = entry.lunacy$getHeight();
        int x = entryX + 2;
        int y = entryY + 2;
        int width = Math.max(1, entryWidth - 4);
        int height = Math.max(1, entryHeight - 4);
        boolean active = mouseX >= entryX && mouseX < entryX + entryWidth
                && mouseY >= entryY && mouseY < entryY + entryHeight;
        int accent = ((entryY / Math.max(1, entryHeight)) & 1) == 0
                ? LunacyMenuChrome.GREEN : LunacyMenuChrome.VIOLET;
        UiRenderer.roundedRect(context, x, y, width, height, 10,
                active ? 0xEE1A2721 : 0xD9131D18);
        UiRenderer.roundedRect(context, x + 12, y + 1, Math.max(0, width - 24), 1,
                0.5, ColorUtil.withAlpha(accent, active ? 100 : 38));
    }
}
