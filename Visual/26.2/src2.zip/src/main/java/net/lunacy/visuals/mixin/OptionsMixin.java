package net.lunacy.visuals.mixin;

import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Add to lunacyvisuals.mixins.json client: "OptionsMixin"
 *
 * First launch (onboardAccessibility) writes guiScale=2 instead of Auto,
 * so the vanilla onboarding screen and the custom title menu get a
 * readable 960x540 GUI on 1080p instead of 480x270.
 */
@Mixin(Options.class)
public class OptionsMixin {
    @Shadow
    public boolean onboardAccessibility;

    @Shadow
    @Final
    private OptionInstance<Integer> guiScale;

    @Inject(method = "load()V", at = @At("RETURN"))
    private void lunacyvisuals$firstLaunchGuiScale(CallbackInfo ci) {
        if (!this.onboardAccessibility) {
            return;
        }
        if (this.guiScale.get() == 0) {
            this.guiScale.set(2);
        }
    }
}
