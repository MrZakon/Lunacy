package net.lunacy.visuals.module;

import net.lunacy.visuals.module.impl.hud.ArmorHudModule;
import net.lunacy.visuals.module.impl.hud.CustomCrosshairModule;
import net.lunacy.visuals.module.impl.hud.TargetHudModule;
import net.lunacy.visuals.module.impl.hud.WatermarkModule;
import net.lunacy.visuals.module.impl.visual.*;

/** Единственная декларация визуальных модулей клиента. */
public final class ModuleRegistry {
    private ModuleRegistry() {}

    public static void registerAll(ModuleManager modules) {
        modules.register(new WatermarkModule());
        modules.register(new TargetHudModule());
        modules.register(new ArmorHudModule());
        modules.register(new CustomCrosshairModule());
        modules.register(new ViewModelModule());
        modules.register(new MotionTrailsModule());
        modules.register(new ChinaHatModule());
        modules.register(new JumpHitParticlesModule());
        modules.register(new AmbienceModule());
        modules.register(new FullbrightModule());
        modules.register(new CameraFxModule());
        modules.register(new ScoreboardBossBarModule());
        modules.register(new CustomChatModule());
        modules.register(new HitColorModule());
        modules.register(new ItemGlintOverlayModule());
        modules.register(new NametagsModule());
        modules.register(new CapeWingsModule());
        modules.register(new OrbitingCosmeticsModule());
        modules.register(new CompanionSpiritModule());
        modules.register(new GroundAuraModule());
        modules.register(new BodyAuraModule());
    }
}
