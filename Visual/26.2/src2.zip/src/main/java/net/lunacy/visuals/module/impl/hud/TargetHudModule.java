package net.lunacy.visuals.module.impl.hud;

import net.lunacy.visuals.animation.SpringValue;
import net.lunacy.visuals.gui.LunacyTheme;
import net.lunacy.visuals.hud.HudAnchor;
import net.lunacy.visuals.hud.HudPosition;
import net.lunacy.visuals.render.UiRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

public final class TargetHudModule extends HudModule {
    private static final Identifier BODY = Identifier.fromNamespaceAndPath("visual-test", "textures/gui/target/target_body.png");
    private static final Identifier ROOM = Identifier.fromNamespaceAndPath("visual-test", "textures/gui/target/target_room.png");
    private static final Identifier HEALTH = Identifier.fromNamespaceAndPath("visual-test", "textures/gui/target/target_health.png");
    private final SpringValue health = new SpringValue(1.0, 220.0, 28.0);
    private String targetName = "Target";
    private float targetHealth = 1.0F;
    private float distance;
    private long lastTargetAt;

    public TargetHudModule() {
        super("target_hud", "TargetHUD", "Target name, animated health and distance",
                new HudPosition(HudAnchor.CENTER, 0, 54, 1));
    }

    @Override protected double width() { return 152; }
    @Override protected double height() { return 48; }

    @Override
    protected void beforeRender() {
        Minecraft client = Minecraft.getInstance();
        if (client.hitResult instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity living
                && living.isAlive()) {
            targetName = living.getName().getString();
            targetHealth = Math.clamp(living.getHealth() / Math.max(1.0F, living.getMaxHealth()), 0.0F, 1.0F);
            if (client.player != null) distance = client.player.distanceTo(living);
            lastTargetAt = System.currentTimeMillis();
        }
    }

    @Override
    protected boolean shouldRender() {
        Minecraft client = Minecraft.getInstance();
        return System.currentTimeMillis() - lastTargetAt < 1400
                || client.gui.screen() instanceof net.lunacy.visuals.gui.ClickGuiScreen screen && screen.isEditingHud();
    }

    @Override
    protected void render(GuiGraphicsExtractor context, double x, double y, double scale, float tickDelta) {
        health.setTarget(targetHealth);
        health.update(ClientRuntimeFrame.delta());
        UiRenderer.shadow(context, x, y, width(), height(), 8, LunacyTheme.accent());
        UiRenderer.texture(context, BODY, x, y, width(), height(), 720, 224);
        UiRenderer.texture(context, ROOM, x + 8, y + 8, 30, 30, 400, 400);
        UiRenderer.text(context, targetName, x + 46, y + 8, 0xFFF1F4F6, false);
        UiRenderer.text(context, String.format("%.1f m  В·  %.0f%%", distance, targetHealth * 100.0F),
                x + 46, y + 20, 0xFF9CA8AE, false);
        UiRenderer.texture(context, HEALTH, x + 46, y + 34, 96 * health.value(), 3, 440, 8,
                LunacyTheme.accent());
    }
}
