package net.lunacy.visuals.module.impl.hud;

import net.lunacy.visuals.ClientRuntime;
import net.lunacy.visuals.LunacyVisuals;
import net.lunacy.visuals.hud.HudAnchor;
import net.lunacy.visuals.hud.BossBarLayout;
import net.lunacy.visuals.hud.HudPosition;
import net.lunacy.visuals.mixin.BossBarHudAccessor;
import net.lunacy.visuals.module.setting.BooleanSetting;
import net.lunacy.visuals.module.setting.ColorSetting;
import net.lunacy.visuals.module.setting.ColorValue;
import net.lunacy.visuals.module.impl.visual.ScoreboardBossBarModule;
import net.lunacy.visuals.render.UiRenderer;
import net.lunacy.visuals.render.font.FontFace;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public final class WatermarkModule extends HudModule {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final Identifier LOGO = Identifier.fromNamespaceAndPath(LunacyVisuals.MOD_ID, "textures/gui/lv_logo.png");
    private static final double DEFAULT_Y = 7;
    private static final double BOSS_BAR_GAP = 8;
    private final BooleanSetting fps = add(new BooleanSetting("fps", "FPS", "Show current framerate", true));
    private final BooleanSetting ping = add(new BooleanSetting("ping", "Ping", "Show network latency", true));
    private final BooleanSetting clock = add(new BooleanSetting("clock", "Clock", "Show local time", true));
    private final ColorSetting accent = add(new ColorSetting("accent", "Accent", "Brand accent",
            new ColorValue(0xFF5CE1E6, 0xFFB18CFF, false, 1.0)));
    private String line = "Lunacy";
    private double adaptiveY = DEFAULT_Y;

    public WatermarkModule() {
        super("watermark", "Watermark", "Brand, FPS, ping, time and player profile",
                new HudPosition(HudAnchor.TOP_CENTER, 0, 7, 1));
    }

    @Override public boolean isLocked() { return true; }

    @Override
    public HudPosition position() {
        return new HudPosition(HudAnchor.TOP_CENTER, 0, adaptiveY, 1);
    }

    @Override public void moveTo(double x, double y) {}
    @Override public void setScale(double scale) {}

    @Override protected double width() {
        return Math.max(132, UiRenderer.fontWidth(FontFace.GOLOS_SEMI, line, 8.4) + 40);
    }
    @Override protected double height() { return 28; }

    @Override
    protected void beforeRender() {
        Minecraft client = Minecraft.getInstance();
        adaptiveY = resolveAdaptiveY(client);
        StringBuilder value = new StringBuilder("Lunacy");
        if (fps.get()) value.append("  ·  ").append(client.getFps()).append(" FPS");
        if (ping.get() && client.player != null && client.getConnection() != null) {
            var entry = client.getConnection().getPlayerInfo(client.player.getUUID());
            if (entry != null) value.append("  ·  ").append(entry.getLatency()).append(" ms");
        }
        if (clock.get()) value.append("  ·  ").append(LocalTime.now().format(CLOCK));
        line = value.toString();
    }

    private static double resolveAdaptiveY(Minecraft client) {
        int count = ((BossBarHudAccessor) client.gui.hud.getBossOverlay()).lunacy$getBossBars().size();
        if (count == 0) return DEFAULT_Y;

        ClientRuntime runtime = ClientRuntime.getNullable();
        ScoreboardBossBarModule module = runtime == null ? null : runtime.module(ScoreboardBossBarModule.class);
        boolean custom = module != null && module.isEnabled()
                && module.bossBarStyle() == ScoreboardBossBarModule.PanelStyle.CUSTOM;
        boolean hidden = module != null && module.isEnabled()
                && module.bossBarStyle() == ScoreboardBossBarModule.PanelStyle.HIDDEN;
        if (hidden) return DEFAULT_Y;

        int bottom = BossBarLayout.visibleBottom(count, client.getWindow().getGuiScaledHeight(), custom);
        return bottom <= 0 ? DEFAULT_Y : Math.max(DEFAULT_Y, bottom + BOSS_BAR_GAP);
    }

    @Override
    protected void render(GuiGraphicsExtractor context, double x, double y, double scale, float tickDelta) {
        int color = accent.get().colorAt(0.25, System.currentTimeMillis());
        UiRenderer.roundedRect(context, x, y, width(), height(), 12, 0xED111A16);
        UiRenderer.roundedBorder(context, x, y, width(), height(), 12, 1,
                net.lunacy.visuals.render.ColorUtil.withAlpha(color, 125));
        UiRenderer.texture(context, LOGO, x + 5, y + 3, 22, 22, 128, 128);
        UiRenderer.font(context, FontFace.GOLOS_SEMI, line, x + 32, y + 8.7,
                8.4, 0xFFF4FFF8);
    }
}
