package net.lunacy.visuals.module.impl.visual;

import net.lunacy.visuals.ClientRuntime;
import net.lunacy.visuals.config.ClientSettings;
import net.lunacy.visuals.event.Subscribe;
import net.lunacy.visuals.event.impl.Render2DEvent;
import net.lunacy.visuals.module.Module;
import net.lunacy.visuals.module.ModuleCategory;
import net.lunacy.visuals.module.setting.BooleanSetting;
import net.lunacy.visuals.module.setting.DoubleSetting;
import net.lunacy.visuals.module.setting.EnumSetting;
import net.lunacy.visuals.render.UiRenderer;
import net.minecraft.client.Minecraft;

/** Safe screen-space effects built around Minecraft's supported GUI blur pass. */
public final class CameraFxModule extends Module {
    public enum Profile { SUBTLE, BALANCED, CINEMATIC }

    private final EnumSetting<Profile> profile = add(new EnumSetting<>(
            "profile", "Profile", "Effect response and edge treatment", Profile.BALANCED, Profile.class));
    private final BooleanSetting motionBlur = add(new BooleanSetting(
            "motion_blur", "Motion blur", "Apply a guarded blur pass while moving", true));
    private final DoubleSetting blur = add(new DoubleSetting(
            "blur", "Blur response", "Movement response and edge intensity", 0.32, 0.05, 1.0, 0.05));
    private final DoubleSetting fovBoost = add(new DoubleSetting(
            "fov_boost", "FOV boost", "Additional speed-reactive field of view", 6, 0, 20, 0.5));
    private final BooleanSetting vignette = add(new BooleanSetting(
            "vignette", "Vignette", "Soft cinematic edge shading", true));
    private final BooleanSetting movementOnly = add(new BooleanSetting(
            "movement_only", "Movement only", "Do not blur a stationary frame", true));
    private long frame;

    public CameraFxModule() {
        super("camera_fx", "Motion Blur & Camera FX", "Working blur, speed FOV and adaptive vignette",
                ModuleCategory.RENDER_FX);
    }

    @Override public String displayValue() { return profile.get().name(); }
    public float fovBoost() { return fovBoost.get().floatValue(); }

    @Subscribe
    private void onRender(Render2DEvent event) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.gui.screen() != null) return;
        double speed = Math.clamp(client.player.getDeltaMovement().horizontalDistance() * 5.0, 0.0, 1.0);
        boolean moving = speed > 0.035;
        ClientSettings.ShaderQuality quality = ClientRuntime.get().settings().shaderQuality();
        int cadence = switch (quality) {
            case PERFORMANCE -> 3;
            case BALANCED -> 2;
            case QUALITY -> 1;
        };
        if (motionBlur.get() && (!movementOnly.get() || moving) && frame++ % cadence == 0) {
            UiRenderer.tryBlur(event.context());
        }

        int width = client.getWindow().getGuiScaledWidth();
        int height = client.getWindow().getGuiScaledHeight();
        double profileStrength = switch (profile.get()) {
            case SUBTLE -> 0.55;
            case BALANCED -> 1.0;
            case CINEMATIC -> 1.45;
        };
        if (motionBlur.get() && moving) {
            int washAlpha = (int) Math.clamp(blur.get() * speed * profileStrength * 7.0, 0, 12);
            UiRenderer.rect(event.context(), 0, 0, width, height, washAlpha << 24 | 0x002D2840);
        }
        if (!vignette.get()) return;
        int edgeAlpha = (int) Math.clamp((5 + blur.get() * 25 * (0.35 + speed)) * profileStrength, 3, 42);
        for (int i = 0; i < 16; i++) {
            int alpha = edgeAlpha * (16 - i) / 16;
            UiRenderer.border(event.context(), i, i, width - i * 2.0, height - i * 2.0, 1, alpha << 24);
        }
    }
}
