package net.lunacy.visuals.module.impl.visual;

import net.lunacy.visuals.event.Subscribe;
import net.lunacy.visuals.event.impl.Render2DEvent;
import net.lunacy.visuals.gui.LunacyMenuChrome;
import net.lunacy.visuals.module.Module;
import net.lunacy.visuals.module.ModuleCategory;
import net.lunacy.visuals.module.setting.BooleanSetting;
import net.lunacy.visuals.module.setting.DoubleSetting;
import net.lunacy.visuals.render.ColorUtil;
import net.lunacy.visuals.render.UiRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.Locale;

/** Compact screen-space player labels with stable projection and a theme-independent dark material. */
public final class NametagsModule extends Module {
    private final BooleanSetting health = add(new BooleanSetting("health", "Health", "Show player health", true));
    private final BooleanSetting badges = add(new BooleanSetting("badges", "Badges", "Show the Lunacy LV badge", true));
    private final DoubleSetting range = add(new DoubleSetting("range", "Range", "Maximum render distance", 24, 4, 64, 1));

    public NametagsModule() {
        super("nametags", "Custom Nametags", "Dark readable player labels with distance-aware scaling",
                ModuleCategory.COSMETICS);
    }

    @Subscribe
    private void onRender(Render2DEvent event) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null || client.gui.screen() != null) return;

        var camera = client.gameRenderer.mainCamera();
        float tickDelta = event.tickDelta();
        double focal = event.context().guiHeight() * 0.5
                / Math.tan(Math.toRadians(client.options.fov().get()) * 0.5);

        for (AbstractClientPlayer player : client.level.players()) {
            double distance = player.distanceTo(client.player);
            if (player == client.player || player.isInvisible() || distance > range.get()) continue;

            var position = player.getPosition(tickDelta);
            Vector3f view = new Vector3f(
                    (float) (position.x - camera.position().x),
                    (float) (position.y + player.getBbHeight() + 0.48 - camera.position().y),
                    (float) (position.z - camera.position().z));
            new Quaternionf(camera.rotation()).conjugate().transform(view);
            if (view.z >= -0.08F) continue;

            double screenX = event.context().guiWidth() * 0.5 + view.x / -view.z * focal;
            double screenY = event.context().guiHeight() * 0.5 - view.y / -view.z * focal;
            if (screenX < -96 || screenX > event.context().guiWidth() + 96
                    || screenY < -32 || screenY > event.context().guiHeight() + 32) continue;

            renderTag(event, player, distance, screenX, screenY);
        }
    }

    private void renderTag(Render2DEvent event, AbstractClientPlayer player,
                           double distance, double screenX, double screenY) {
        String badge = badges.get() ? "LV" : "";
        String name = player.getName().getString();
        String hp = health.get() ? String.format(Locale.ROOT, "%.0f HP", player.getHealth()) : "";
        int badgeWidth = badge.isEmpty() ? 0 : UiRenderer.textWidth(badge) + 9;
        int nameWidth = UiRenderer.textWidth(name);
        int healthWidth = hp.isEmpty() ? 0 : UiRenderer.textWidth(hp) + 10;
        int boxWidth = 14 + badgeWidth + nameWidth + healthWidth;
        int boxHeight = 19;

        double scale = Math.clamp(1.02 - distance / range.get() * 0.20, 0.80, 1.0);
        double x = screenX - boxWidth * scale * 0.5;
        double y = screenY - (boxHeight + 3) * scale;

        event.context().pose().pushMatrix();
        event.context().pose().translate((float) x, (float) y);
        event.context().pose().scale((float) scale, (float) scale);

        UiRenderer.shadow(event.context(), 0, 0, boxWidth, boxHeight, 7,
                ColorUtil.withAlpha(LunacyMenuChrome.GREEN, 72));
        UiRenderer.gradientRoundedRect(event.context(), 0, 0, boxWidth, boxHeight, 7,
                ColorUtil.withAlpha(LunacyMenuChrome.GREEN, 145),
                ColorUtil.withAlpha(LunacyMenuChrome.VIOLET, 145));
        UiRenderer.verticalGradientRoundedRect(event.context(), 1, 1, boxWidth - 2, boxHeight - 2, 6,
                0xF018211D, 0xF00C100E);

        double cursor = 7;
        if (!badge.isEmpty()) {
            UiRenderer.text(event.context(), badge, cursor, 5, LunacyMenuChrome.VIOLET, false);
            cursor += badgeWidth;
            UiRenderer.rect(event.context(), cursor - 5, 5, 1, 9, 0x4677E7A2);
        }
        UiRenderer.text(event.context(), name, cursor, 5, LunacyMenuChrome.TEXT, false);
        cursor += nameWidth;
        if (!hp.isEmpty()) {
            UiRenderer.text(event.context(), hp, cursor + 10, 5, healthColor(player), false);
        }
        event.context().pose().popMatrix();
    }

    private static int healthColor(AbstractClientPlayer player) {
        float maximum = Math.max(1.0F, player.getMaxHealth());
        float fraction = Math.clamp(player.getHealth() / maximum, 0.0F, 1.0F);
        if (fraction > 0.60F) return LunacyMenuChrome.GREEN;
        if (fraction > 0.30F) return 0xFFFFD36B;
        return LunacyMenuChrome.DANGER;
    }
}
