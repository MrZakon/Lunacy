package net.lunacy.visuals.module.impl.visual;

import net.lunacy.visuals.gui.LunacyTheme;
import net.lunacy.visuals.module.Module;
import net.lunacy.visuals.module.ModuleCategory;
import net.lunacy.visuals.module.setting.ColorSetting;
import net.lunacy.visuals.module.setting.ColorValue;
import net.lunacy.visuals.module.setting.DoubleSetting;
import net.lunacy.visuals.module.setting.EnumSetting;
import net.lunacy.visuals.render.ColorUtil;

public final class ScoreboardBossBarModule extends Module {
    public enum PanelStyle { CUSTOM, VANILLA, HIDDEN }

    private final EnumSetting<PanelStyle> scoreboard = add(new EnumSetting<>(
            "scoreboard", "Scoreboard", "Custom, vanilla, or hidden scoreboard", PanelStyle.CUSTOM, PanelStyle.class));
    private final EnumSetting<PanelStyle> bossBar = add(new EnumSetting<>(
            "boss_bar", "Boss bar", "Custom, vanilla, or hidden boss bars", PanelStyle.CUSTOM, PanelStyle.class));
    private final ColorSetting accent = add(new ColorSetting(
            "accent", "Accent", "Panel gradient", new ColorValue(0xFF77E7A2, 0xFFA66BFF, false, 0.7)));
    private final DoubleSetting opacity = add(new DoubleSetting(
            "background_alpha", "Background opacity", "Opacity of custom HUD panels", 0.82, 0.35, 1, 0.05));

    public ScoreboardBossBarModule() {
        super("scoreboard_bossbar", "Scoreboard & Boss Bars", "Content-sized custom HUD panels",
                ModuleCategory.HUD);
    }

    @Override public String displayValue() { return scoreboard.get().name(); }
    public PanelStyle scoreboardStyle() { return scoreboard.get(); }
    public PanelStyle bossBarStyle() { return bossBar.get(); }

    public int accent(double progress, long now) {
        return accent.get().colorAt(progress, now);
    }

    public int panelColor(int baseAlpha) {
        int alpha = (int) Math.round(baseAlpha * opacity.get());
        return ColorUtil.withAlpha(LunacyTheme.dark() ? 0xFF0B100E : 0xFFF8F7F4, alpha);
    }
}
