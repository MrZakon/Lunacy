package net.lunacy.visuals.render;

import net.lunacy.visuals.ClientRuntime;
import net.lunacy.visuals.render.font.FontFace;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/** Быстрые 2D-примитивы для HUD и экранов; координаты уже в GUI-space. */
public final class UiRenderer {
    private UiRenderer() {}

    public static void rect(GuiGraphicsExtractor context, double x, double y, double width, double height, int color) {
        context.fill(round(x), round(y), round(x + width), round(y + height), color);
    }

    public static void roundedRect(GuiGraphicsExtractor context, double x, double y, double width, double height,
                                   double radius, int color) {
        int r = Math.max(0, Math.min(round(radius), Math.min(round(width), round(height)) / 2));
        if (r <= 1) {
            rect(context, x, y, width, height, color);
            return;
        }
        rect(context, x + r, y, width - r * 2.0, height, color);
        rect(context, x, y + r, width, height - r * 2.0, color);
        for (int line = 0; line < r; line++) {
            double dy = r - line - 0.5;
            int inset = (int) Math.ceil(r - Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            rect(context, x + inset, y + line, width - inset * 2.0, 1, color);
            rect(context, x + inset, y + height - line - 1, width - inset * 2.0, 1, color);
        }
    }

    public static void shadow(GuiGraphicsExtractor context, double x, double y, double width, double height,
                              double radius, int color) {
        for (int i = 4; i >= 1; i--) {
            roundedRect(context, x - i, y - i, width + i * 2.0, height + i * 2.0,
                    radius + i, ColorUtil.withAlpha(color, Math.max(4, 22 - i * 4)));
        }
    }

    public static void border(GuiGraphicsExtractor context, double x, double y, double width, double height,
                              double thickness, int color) {
        rect(context, x, y, width, thickness, color);
        rect(context, x, y + height - thickness, width, thickness, color);
        rect(context, x, y, thickness, height, color);
        rect(context, x + width - thickness, y, thickness, height, color);
    }

    /** Draws a true rounded outline without the square corner artifacts of {@link #border}. */
    public static void roundedBorder(GuiGraphicsExtractor context, double x, double y, double width, double height,
                                     double radius, double thickness, int color) {
        int h = Math.max(1, round(height));
        int w = Math.max(1, round(width));
        int r = Math.max(0, Math.min(round(radius), Math.min(w, h) / 2));
        int t = Math.max(1, Math.min(round(thickness), Math.min(w, h) / 2));
        if (r <= 1) {
            border(context, x, y, w, h, t, color);
            return;
        }

        // Straight spans are constant; drawing them once avoids two draw calls for every
        // middle row of large menu cards and lists.
        rect(context, x, y + r, t, Math.max(0, h - r * 2.0), color);
        rect(context, x + w - t, y + r, t, Math.max(0, h - r * 2.0), color);
        for (int row = 0; row < r; row++) {
            int outer = roundedInset(row, h, r);
            if (row < t || row >= h - t || w <= t * 2) {
                rect(context, x + outer, y + row, Math.max(0, w - outer * 2), 1, color);
            } else {
                int innerHeight = h - t * 2;
                int innerRadius = Math.max(0, r - t);
                int inner = t + roundedInset(row - t, innerHeight, innerRadius);
                double segment = Math.max(0, inner - outer);
                rect(context, x + outer, y + row, segment, 1, color);
                rect(context, x + w - inner, y + row, segment, 1, color);
            }

            int bottomRow = h - row - 1;
            int bottomOuter = roundedInset(bottomRow, h, r);
            if (row < t || w <= t * 2) {
                rect(context, x + bottomOuter, y + bottomRow,
                        Math.max(0, w - bottomOuter * 2), 1, color);
            } else {
                int innerHeight = h - t * 2;
                int innerRadius = Math.max(0, r - t);
                int inner = t + roundedInset(bottomRow - t, innerHeight, innerRadius);
                double segment = Math.max(0, inner - bottomOuter);
                rect(context, x + bottomOuter, y + bottomRow, segment, 1, color);
                rect(context, x + w - inner, y + bottomRow, segment, 1, color);
            }
        }
    }

    public static void horizontalGradient(GuiGraphicsExtractor context, double x, double y, double width, double height,
                                          int leftColor, int rightColor) {
        // DrawContext exposes a smooth two-vertex gradient vertically. Rotate that quad by 90°
        // instead of assembling the horizontal gradient from dozens of overlapping pixel strips.
        // The old strip implementation produced the clearly visible vertical lines on menu art.
        context.pose().pushMatrix();
        context.pose().translate((float) x, (float) y);
        context.pose().rotate((float) (-Math.PI / 2.0));
        context.fillGradient(round(-height), 0, 0, round(width), leftColor, rightColor);
        context.pose().popMatrix();
    }

    public static void verticalGradientRoundedRect(GuiGraphicsExtractor context, double x, double y,
                                                   double width, double height, double radius,
                                                   int topColor, int bottomColor) {
        int h = Math.max(1, round(height));
        int w = Math.max(1, round(width));
        int r = Math.max(0, Math.min(round(radius), Math.min(w, h) / 2));
        if (r <= 1) {
            context.fillGradient(round(x), round(y), round(x + width), round(y + height),
                    topColor, bottomColor);
            return;
        }

        context.fillGradient(round(x + r), round(y), round(x + width - r), round(y + height),
                topColor, bottomColor);
        int middleTop = colorAt(topColor, bottomColor, r, h);
        int middleBottom = colorAt(topColor, bottomColor, h - r, h);
        context.fillGradient(round(x), round(y + r), round(x + width), round(y + height - r),
                middleTop, middleBottom);
        for (int row = 0; row < r; row++) {
            int inset = roundedInset(row, h, r);
            int color = ColorUtil.mix(topColor, bottomColor, row / (float) Math.max(1, h - 1));
            rect(context, x + inset, y + row, Math.max(0, w - inset * 2), 1, color);
            int bottomRow = h - row - 1;
            int bottomInset = roundedInset(bottomRow, h, r);
            int bottom = ColorUtil.mix(topColor, bottomColor,
                    bottomRow / (float) Math.max(1, h - 1));
            rect(context, x + bottomInset, y + bottomRow,
                    Math.max(0, w - bottomInset * 2), 1, bottom);
        }
    }

    /** A shader-free horizontal gradient with rounded end caps. */
    public static void gradientRoundedRect(GuiGraphicsExtractor context, double x, double y, double width, double height,
                                           double radius, int leftColor, int rightColor) {
        double r = Math.max(0, Math.min(radius, Math.min(width, height) / 2.0));
        roundedRect(context, x, y, width, height, r, leftColor);
        if (width <= r * 2.0) return;
        horizontalGradient(context, x + r, y, width - r * 2.0, height, leftColor, rightColor);
        roundedRect(context, x + width - r * 2.0, y, r * 2.0, height, r, rightColor);
    }

    public static void text(GuiGraphicsExtractor context, String value, double x, double y, int color, boolean shadow) {
        ClientRuntime runtime = ClientRuntime.getNullable();
        if (runtime == null) {
            context.text(Minecraft.getInstance().font, value, round(x), round(y), color, shadow);
            return;
        }
        if (shadow) runtime.renderEngine().fonts().draw(context, value, (float) x + 1, (float) y + 1,
                9.0F, ColorUtil.withAlpha(0xFF000000, Math.max(70, (color >>> 24) / 2)));
        runtime.renderEngine().fonts().draw(context, value, (float) x, (float) y, 9.0F, color);
    }

    public static int textWidth(String value) {
        ClientRuntime runtime = ClientRuntime.getNullable();
        return runtime == null ? Minecraft.getInstance().font.width(value)
                : Math.round(runtime.renderEngine().fonts().width(value, 9.0F));
    }

    public static void textScaled(GuiGraphicsExtractor context, String value, double x, double y, int color,
                                  boolean shadow, double scale) {
        ClientRuntime runtime = ClientRuntime.getNullable();
        if (runtime == null) {
            context.pose().pushMatrix();
            context.pose().translate((float) x, (float) y);
            context.pose().scale((float) scale, (float) scale);
            context.text(Minecraft.getInstance().font, value, 0, 0, color, shadow);
            context.pose().popMatrix();
            return;
        }
        float size = (float) (9.0 * scale);
        if (shadow) runtime.renderEngine().fonts().draw(context, value, (float) x + 1, (float) y + 1,
                size, ColorUtil.withAlpha(0xFF000000, Math.max(70, (color >>> 24) / 2)));
        runtime.renderEngine().fonts().draw(context, value, (float) x, (float) y, size, color);
    }

    public static void font(GuiGraphicsExtractor context, FontFace face, String value,
                            double x, double y, double size, int color) {
        ClientRuntime runtime = ClientRuntime.getNullable();
        if (runtime == null) {
            textScaled(context, value, x, y, color, false, size / 9.0);
            return;
        }
        runtime.renderEngine().fonts().draw(context, face, value, (float) x, (float) y, (float) size, color);
    }

    public static double fontWidth(FontFace face, String value, double size) {
        ClientRuntime runtime = ClientRuntime.getNullable();
        return runtime == null ? Minecraft.getInstance().font.width(value) * size / 9.0
                : runtime.renderEngine().fonts().width(face, value, (float) size);
    }

    /** Minecraft's batched font path, used by dense screens for maximum clarity and speed. */
    public static void vanillaText(GuiGraphicsExtractor context, String value, double x, double y,
                                   double scale, int color, boolean shadow) {
        context.pose().pushMatrix();
        context.pose().translate((float) x, (float) y);
        context.pose().scale((float) scale, (float) scale);
        context.text(Minecraft.getInstance().font, value, 0, 0, color, shadow);
        context.pose().popMatrix();
    }

    public static double vanillaTextWidth(String value, double scale) {
        return Minecraft.getInstance().font.width(value) * scale;
    }

    public static void spacedFont(GuiGraphicsExtractor context, FontFace face, String value,
                                  double x, double y, double size, double spacing, int color) {
        double cursor = x;
        for (int offset = 0; offset < value.length();) {
            int codePoint = value.codePointAt(offset);
            String glyph = new String(Character.toChars(codePoint));
            font(context, face, glyph, cursor, y, size, color);
            cursor += fontWidth(face, glyph, size) + spacing;
            offset += Character.charCount(codePoint);
        }
    }

    public static double spacedFontWidth(FontFace face, String value, double size, double spacing) {
        double width = 0;
        int count = 0;
        for (int offset = 0; offset < value.length();) {
            int codePoint = value.codePointAt(offset);
            width += fontWidth(face, new String(Character.toChars(codePoint)), size);
            count++;
            offset += Character.charCount(codePoint);
        }
        return width + Math.max(0, count - 1) * spacing;
    }

    public static void spacedText(GuiGraphicsExtractor context, String value, double x, double y, int color,
                                  double scale, int spacing) {
        double cursor = x;
        for (int offset = 0; offset < value.length();) {
            int codePoint = value.codePointAt(offset);
            String glyph = new String(Character.toChars(codePoint));
            textScaled(context, glyph, cursor, y, color, false, scale);
            cursor += (textWidth(glyph) + spacing) * scale;
            offset += Character.charCount(codePoint);
        }
    }

    public static double spacedTextWidth(String value, double scale, int spacing) {
        double width = 0;
        int glyphs = 0;
        for (int offset = 0; offset < value.length();) {
            int codePoint = value.codePointAt(offset);
            width += textWidth(new String(Character.toChars(codePoint))) * scale;
            glyphs++;
            offset += Character.charCount(codePoint);
        }
        return width + Math.max(0, glyphs - 1) * spacing * scale;
    }

    /** Draws a complete PNG at GUI coordinates without making callers repeat pipeline boilerplate. */
    public static void texture(GuiGraphicsExtractor context, Identifier texture, double x, double y,
                               double width, double height, int textureWidth, int textureHeight) {
        context.blit(RenderPipelines.GUI_TEXTURED, texture, round(x), round(y), 0, 0,
                round(width), round(height), textureWidth, textureHeight, textureWidth, textureHeight);
    }

    /** Draws a complete PNG with an ARGB multiplier, useful for restrained background artwork. */
    public static void texture(GuiGraphicsExtractor context, Identifier texture, double x, double y,
                               double width, double height, int textureWidth, int textureHeight, int color) {
        context.blit(RenderPipelines.GUI_TEXTURED, texture, round(x), round(y), 0, 0,
                round(width), round(height), textureWidth, textureHeight, textureWidth, textureHeight, color);
    }

    /** Draws a full texture with a tiny source inset to prevent edge texel repetition when scaled. */
    public static void textureInset(GuiGraphicsExtractor context, Identifier texture, double x, double y,
                                    double width, double height, int textureWidth, int textureHeight,
                                    int inset) {
        int safeInset = Math.max(0, Math.min(inset, Math.min(textureWidth, textureHeight) / 4));
        context.blit(RenderPipelines.GUI_TEXTURED, texture, round(x), round(y),
                safeInset, safeInset, round(width), round(height),
                Math.max(1, textureWidth - safeInset * 2), Math.max(1, textureHeight - safeInset * 2),
                textureWidth, textureHeight);
    }

    public static void textureRegion(GuiGraphicsExtractor context, Identifier texture, double x, double y,
                                     double width, double height, float sourceX, float sourceY,
                                     int sourceWidth, int sourceHeight,
                                     int textureWidth, int textureHeight, int color) {
        context.blit(RenderPipelines.GUI_TEXTURED, texture, round(x), round(y), sourceX, sourceY,
                round(width), round(height), sourceWidth, sourceHeight, textureWidth, textureHeight, color);
    }

    /** Draws a Minecraft GUI sprite, including its nine-slice metadata when present. */
    public static void guiSprite(GuiGraphicsExtractor context, Identifier sprite, double x, double y,
                                 double width, double height) {
        context.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, round(x), round(y), round(width), round(height));
    }

    public static boolean inside(double mouseX, double mouseY, double x, double y, double width, double height) {
        return mouseX >= x && mouseY >= y && mouseX < x + width && mouseY < y + height;
    }

    /** Minecraft допускает только один blur-pass на кадр; overlay мог уже его выполнить. */
    public static void tryBlur(GuiGraphicsExtractor context) {
        try {
            context.blurBeforeThisStratum();
        } catch (IllegalStateException ignored) {
            // Текущий кадр уже размыт другим экраном или загрузочным overlay.
        }
    }

    private static int round(double value) {
        return (int) Math.round(value);
    }

    private static int roundedInset(int row, int height, int radius) {
        if (radius <= 1 || (row >= radius && row < height - radius)) return 0;
        double dy = row < radius ? radius - row - 0.5 : row - (height - radius) + 0.5;
        return (int) Math.ceil(radius - Math.sqrt(Math.max(0.0, radius * radius - dy * dy)));
    }

    private static int colorAt(int top, int bottom, int row, int height) {
        return ColorUtil.mix(top, bottom, row / (float) Math.max(1, height - 1));
    }
}
